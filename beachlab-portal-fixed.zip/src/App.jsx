
import React, { useState } from "react";
import { CalendarDays, Users, Phone, Mail, MapPin, Waves, Send, Upload, CheckCircle } from "lucide-react";
import "./style.css";

export default function App() {
  const roomOptions = [
    { name: "Villa 1", price: 8800 },
    { name: "Villa 2", price: 7500 },
    { name: "Villa 3", price: 7500 },
    { name: "Guest Room 1", price: 7500 },
    { name: "Guest Room 2", price: 8800 },
  ];

  const [selectedRoom, setSelectedRoom] = useState(roomOptions[0]);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [reservationSubmitted, setReservationSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "", phone: "", email: "", checkIn: "", checkOut: "", guests: "", message: ""
  });

  const bookingReference = `BL-${Math.floor(100000 + Math.random() * 900000)}`;

  const bankDetails = {
    bankName: "YOUR BANK NAME",
    accountName: "YOUR ACCOUNT NAME",
    accountNumber: "YOUR ACCOUNT NUMBER",
  };

  const gcashName = "YOUR GCASH NAME";
  const gcashNumber = "YOUR GCASH NUMBER";
  const paypalLink = "https://www.paypal.com/paypalme/YOURPAYPALUSERNAME";

  const reservationMessage = encodeURIComponent(
    `Hi BeachLab! I would like to make a reservation.\n\nName: ${form.name}\nPhone: ${form.phone}\nEmail: ${form.email}\nRoom: ${selectedRoom.name}\nAmount: ₱${selectedRoom.price.toLocaleString()}\nCheck-in: ${form.checkIn}\nCheck-out: ${form.checkOut}\nGuests: ${form.guests}\nMessage: ${form.message}`
  );

  const messengerLink = "https://m.me/BeachLabPH";
  const whatsappLink = `https://wa.me/639770769680?text=${reservationMessage}`;
  const emailLink = `mailto:thebeachlab18@gmail.com?subject=BeachLab Reservation Inquiry&body=${reservationMessage}`;

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  return (
    <div className="page">
      <section className="hero">
        <div className="heroText">
          <div className="badge"><Waves size={16}/> Tabuelan, Cebu White Sandbar Stay</div>
          <h1>Reserve Your BeachLab Getaway</h1>
          <p>Experience Tabuelan’s white sandbar, relaxing beach vibes, and unforgettable sunsets at The BeachLab.</p>
          <div className="buttonRow">
            <a className="primaryBtn" href="#reservation">Book Now</a>
            <a className="outlineBtn" href={messengerLink} target="_blank">Message Us</a>
          </div>
        </div>
        <div className="heroCard">
          <div className="photoCard">
            <div className="glassBox">
              <p>The BeachLab</p>
              <h2>Sun. Sandbar. Smiles.</h2>
              <span>Your private coastal escape in Tabuelan, Cebu.</span>
            </div>
          </div>
        </div>
      </section>

      <section className="features">
        <Feature icon={<MapPin />} title="Location" text="Maravilla, Tabuelan, Cebu" />
        <Feature icon={<Users />} title="Perfect For" text="Families, friends, outings, and celebrations" />
        <Feature icon={<CalendarDays />} title="Easy Booking" text="Choose your room, checkout, and upload proof of payment." />
      </section>

      <section id="reservation" className="portal">
        <div className="leftInfo">
          <h2>Reservation Portal</h2>
          <p>Fill out your details, select your room, review the agreement, then proceed to payment.</p>

          <div className="contactBox">
            <h3>Contact Details</h3>
            <p><Phone size={16}/> 0977 076 9680</p>
            <p><Mail size={16}/> thebeachlab18@gmail.com</p>
            <p><MapPin size={16}/> Maravilla, Tabuelan, Cebu</p>
          </div>
        </div>

        <div className="formCard">
          <div className="formGrid">
            <input name="name" placeholder="Full Name" value={form.name} onChange={handleChange} />
            <input name="phone" placeholder="Phone Number" value={form.phone} onChange={handleChange} />
            <input name="email" placeholder="Email Address" value={form.email} onChange={handleChange} className="span2" />
            <input name="checkIn" type="date" value={form.checkIn} onChange={handleChange} />
            <input name="checkOut" type="date" value={form.checkOut} onChange={handleChange} />
            <input name="guests" placeholder="Number of Guests" value={form.guests} onChange={handleChange} className="span2" />

            <div className="roomSelect span2">
              <label>Choose Your Room</label>
              <div className="roomGrid">
                {roomOptions.map((room) => (
                  <button
                    type="button"
                    key={room.name}
                    onClick={() => setSelectedRoom(room)}
                    className={selectedRoom.name === room.name ? "room active" : "room"}
                  >
                    <strong>{room.name}</strong>
                    <span>₱{room.price.toLocaleString()} / night</span>
                  </button>
                ))}
              </div>
            </div>

            <textarea name="message" placeholder="Special request or question" value={form.message} onChange={handleChange} rows="4" className="span2" />
          </div>

          <div className="sendButtons">
            <a href={messengerLink} target="_blank" className="primaryBtn"><Send size={16}/> Messenger</a>
            <a href={whatsappLink} target="_blank" className="outlineBtn">WhatsApp</a>
            <a href={emailLink} className="outlineBtn">Email</a>
          </div>

          <div className="summaryBox">
            <div>
              <h3>Selected Room</h3>
              <p>{selectedRoom.name}</p>
            </div>
            <div className="price">₱{selectedRoom.price.toLocaleString()}</div>
          </div>

          <button className="checkoutBtn" onClick={() => setShowCheckout(true)}>Proceed to Checkout</button>

          {showCheckout && (
            <div className="checkout">
              <h3>Checkout Agreement</h3>
              <p>Please review and agree to the terms before proceeding with payment.</p>

              <div className="terms">
                <p><strong>Cancellation Policy:</strong> Cancellations made less than 7 days before check-in are non-refundable.</p>
                <p><strong>Rescheduling:</strong> Rescheduling is allowed once only and must be requested before the cancellation deadline.</p>
                <p><strong>No Show:</strong> No-show bookings are non-refundable.</p>
                <p><strong>Payment Confirmation:</strong> Reservation is confirmed only after payment has been verified by The BeachLab.</p>
              </div>

              <label className="checkbox">
                <input type="checkbox" checked={acceptedTerms} onChange={(e) => setAcceptedTerms(e.target.checked)} />
                I have read and agree to The BeachLab reservation, cancellation, rescheduling, and payment terms.
              </label>

              <div className={acceptedTerms ? "paymentBox" : "paymentBox disabled"}>
                <h3>Choose Payment Method</h3>
                <p>Selected room: <strong>{selectedRoom.name}</strong> — ₱{selectedRoom.price.toLocaleString()}</p>

                <div className="paymentGrid">
                  <PaymentCard title="GCash">
                    <p><strong>Name:</strong> {gcashName}</p>
                    <p><strong>Number:</strong> {gcashNumber}</p>
                  </PaymentCard>

                  <PaymentCard title="PayPal">
                    <p>Pay securely through PayPal.</p>
                    <a className="outlineBtn full" href={acceptedTerms ? paypalLink : "#"} target="_blank">Pay via PayPal</a>
                  </PaymentCard>

                  <PaymentCard title="Bank Transfer">
                    <p><strong>Bank:</strong> {bankDetails.bankName}</p>
                    <p><strong>Account Name:</strong> {bankDetails.accountName}</p>
                    <p><strong>Account Number:</strong> {bankDetails.accountNumber}</p>
                  </PaymentCard>
                </div>

                <div className="uploadBox">
                  <Upload />
                  <h3>Upload Proof of Payment</h3>
                  <p>After payment, please upload a screenshot or photo of your receipt for verification.</p>
                  <input type="file" accept="image/*,.pdf" />
                  <small>Accepted files: JPG, PNG, PDF</small>
                  <button disabled={!acceptedTerms} onClick={() => setReservationSubmitted(true)} className="checkoutBtn">Submit Reservation</button>
                </div>

                {reservationSubmitted && (
                  <div className="success">
                    <CheckCircle size={42}/>
                    <h3>Reservation Submitted Successfully</h3>
                    <p>Thank you for choosing The BeachLab 🌴</p>
                    <p>Your payment proof has been received and is pending verification.</p>
                    <div className="ref">
                      <span>Booking Reference</span>
                      <strong>{bookingReference}</strong>
                    </div>
                    <p>Selected Room: <strong>{selectedRoom.name}</strong></p>
                    <p>Amount: <strong>₱{selectedRoom.price.toLocaleString()}</strong></p>
                    <p>Status: <strong className="pending">Pending Verification</strong></p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function Feature({ icon, title, text }) {
  return <div className="feature">{icon}<h3>{title}</h3><p>{text}</p></div>;
}

function PaymentCard({ title, children }) {
  return <div className="payCard"><h4>{title}</h4>{children}<small>Send proof of payment after transfer.</small></div>;
}
